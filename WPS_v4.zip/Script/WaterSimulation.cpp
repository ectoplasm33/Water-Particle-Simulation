// WaterSimulation.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <SDL3/SDL.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <iostream>
#include <string>
#include <cmath>
#include <vector>
#include <random>
#include <unordered_map>

std::random_device rd;
std::mt19937 gen(rd());

std::uniform_real_distribution<float> random(0.0f, 1.0f);

int win_x = 1500; int win_y = std::floor(win_x * 9.0f / 16.0f);

const int circle_radius = 3;

float num_particles = 4000.0f;
float influence_radius = 48.0f;
float target_density = 4.3f;
float pressure_multiplier = 0.3f;
float viscosity_multiplier = 0.13f;
float gravity = 0.3f;

int radius_sq = influence_radius * influence_radius;
float inv_r = 1.0f / influence_radius;
int cell_size = influence_radius;
float inv_cs = 1.0f / cell_size;

const int target_fps = 120;
const float delay = 1000 / target_fps;

float mouse_strength = 0.5f;
float mouse_range = 250.0f;
float mouse_range_sq = mouse_range * mouse_range;

bool l_button = false;
bool r_button = false;

float mouse_x;
float mouse_y;

bool render_colors = false;
bool show_ui = false;

using segment = std::pair<std::pair<float, float>, std::pair<float, float>>;

std::vector<segment> precompute_circle(float r) {
    std::vector<segment> offsets;

    float r2 = r*r;
    float dy;

    for (float dx = -r; dx <= r; dx++) {
        dy = std::floor(std::sqrt(r2 - dx * dx));

        offsets.emplace_back(std::make_pair(dx, dy), std::make_pair(dx, -dy));
    }

    return offsets;
}

std::vector<std::vector<segment>> circle_offsets;

struct hash_key {
    std::size_t operator()(const std::pair<int, int>& p) const noexcept {
        return ((std::size_t)p.first << 32) ^ (std::size_t)p.second;
    }
};

std::string format_float(float value, int precision) {
    int scale = pow(10.0f, precision);
    std::string str = std::to_string(std::round(value * scale) / scale);
    
    while (!str.empty() && str.back() == '0') {
        str.pop_back();
    }

    // Remove trailing decimal point
    if (!str.empty() && str.back() == '.') {
        str.pop_back();
    }


    return str;
}

class Particle {
public:
    float x, y, vx, vy, px, py, density;
    int cx, cy, idx;
    Uint8 r, g, b, a;

    Particle(int i, float initial_x, float initital_y) {
        x = initial_x;
        y = initital_y;
        vx = 0;
        vy = 0;
        px = x;
        py = y;
        cx = std::floor(x * inv_cs);
        cy = std::floor(y * inv_cs);

        r = 0;
        g = 0;
        b = 0;
        a = 0;
        density = 0;

        idx = i;
    }
};

std::vector<Particle> particles;
std::vector<Particle> new_particles;

std::vector<Particle*> current_p;
std::vector<Particle*> new_p;

std::unordered_map<std::pair<int, int>, std::vector<Particle*>, hash_key> grid;

class SliderKnob {
public:
    float x, y, min_x, max_x, min_val, max_val, t_w, t_h;
    float* val;
    bool move;
    SDL_Texture* display_val;
    SDL_FRect display_val_position;

    std::string text;
    SDL_Surface* surf;
    SDL_Color color = { 255,255,255,255 };

    SliderKnob(SDL_Renderer* renderer, float* traceback, float slider_value, float initial_y,  float minimum_x, float maximum_x, float minimum_setting, float maximum_setting, TTF_Font* font) {
        move = false;
        val = traceback;
        min_x = minimum_x;
        max_x = maximum_x;
        min_val = minimum_setting;
        max_val = maximum_setting;

        x = min_x + (slider_value - min_val) / (max_val - min_val) * (max_x - min_x);
        y = initial_y;

        text = format_float(*val, 2);
        
        surf = TTF_RenderText_Blended(font, text.c_str(), SDL_strnlen(text.c_str(), 10), color);
        display_val = SDL_CreateTextureFromSurface(renderer, surf);

        SDL_GetTextureSize(display_val, &t_w, &t_h);

        display_val_position = { std::round(x-t_w*0.5f), std::round(y+14), t_w, t_h };
    }

    inline void update_variable() {
        float previous = *val;

        *val = min_val + (x - min_x) / (max_x - min_x) * (max_val - min_val);

        if (val == &influence_radius) {
            radius_sq = influence_radius * influence_radius;
            cell_size = influence_radius;
            inv_r = 1.0f / influence_radius;
            inv_cs = inv_r;
        }
        else if (val == &num_particles) {
            *val = float(std::round(*val));
            
            float diff = previous - *val;

            if (diff > 0) {
                diff = int(diff);
                particles.erase(particles.end() - diff, particles.end());
                new_particles.erase(new_particles.end() - diff, new_particles.end());
                current_p.erase(current_p.end() - diff, current_p.end());
                new_p.erase(new_p.end() - diff, new_p.end());
            }
            else {
                for (int i = 0; i < -diff; i++) {
                    particles.emplace_back(i, random(gen) * win_x, random(gen) * win_y);
                    new_particles.emplace_back(particles.back());
                    current_p.emplace_back(&particles.back());
                    new_p.emplace_back(&new_particles.back());
                }
            }
        }
        else if (val == &mouse_range) {
            mouse_range_sq = mouse_range * mouse_range;
        }
    }

    inline void update_val_label(SDL_Renderer* renderer, TTF_Font* font) {
        if (val == &num_particles) {
            text = format_float(std::ceil(*val), 0);
        }
        else {
            text = format_float(*val, 2);
        }

        surf = TTF_RenderText_Blended(font, text.c_str(), SDL_strnlen(text.c_str(), 10), color);
        display_val = SDL_CreateTextureFromSurface(renderer, surf);

        SDL_GetTextureSize(display_val, &t_w, &t_h);

        display_val_position = { std::round(x - t_w * 0.5f), std::round(y + 14), t_w, t_h };
    }
};

inline void render(SDL_Renderer* renderer, int index, float x, float y) {
    for (auto& seg : circle_offsets[index]) {
        SDL_RenderLine(renderer, x + seg.first.first, y + seg.first.second, x + seg.second.first, y + seg.second.second);
    }
}

std::vector<SliderKnob> knobs;

inline std::vector<Particle*> get_neighbors(Particle& p) {
    int cx = p.cx;
    int cy = p.cy;

    std::vector<Particle*> neighbors;

    for (int i = -1; i < 2; i++) {
        for (int j = -1; j < 2; j++) {
            auto cell = grid.find({ cx + i, cy + j });

            if (cell != grid.end()) {
                neighbors.insert(neighbors.end(), cell->second.begin(), cell->second.end());
            }
        }
    }

    return neighbors;
}

SDL_Texture* create_slider(SDL_Renderer* renderer, SDL_Texture* text, int w, int h) {
    SDL_SetRenderTarget(renderer, text);

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);

    int thickness = std::floor(h / 5);

    SDL_FRect top = { h, 0, w - h*2, thickness };
    SDL_FRect bottom = { h, h - thickness, w - h*2, thickness };

    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

    SDL_RenderFillRect(renderer, &top);
    SDL_RenderFillRect(renderer, &bottom);

    float outer_r = h * 0.5f;
    float outer_r2 = outer_r * outer_r;
    float inner_r2 = (outer_r - thickness) * (outer_r - thickness);

    float cx = h;
    float cy = h * 0.5f;

    float dist; 

    for (float dx = std::floor(-outer_r); dx < 0; dx++) {
        for (float dy = std::floor(-outer_r); dy < outer_r; dy++) {
            dist = dx * dx + dy * dy;
            if (dist < outer_r2 && dist > inner_r2) {
                SDL_RenderPoint(renderer, cx + dx, cy + dy);
            }
        }
    }

    cx = w - h;

    for (float dx = 0; dx < std::ceil(outer_r); dx++) {
        for (float dy = std::floor(-outer_r); dy < outer_r; dy++) {
            dist = dx * dx + dy * dy;
            if (dist < outer_r2 && dist > inner_r2) {
                SDL_RenderPoint(renderer, cx + dx, cy + dy);
            }
        }
    }

    return text;
}

SDL_Texture* resize_texture(SDL_Renderer* renderer, SDL_Texture* original, int w, int h) {
    SDL_Texture* resized = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, w, h);

    SDL_SetRenderTarget(renderer, resized);
    
    SDL_FRect dest = { 0,0,float(w),float(h) };
    SDL_RenderTexture(renderer, original, nullptr, &dest);
       
    return resized;
}

int main() {
    std::vector<float> radii = { circle_radius, 12 };

    for (auto& r : radii) {
        circle_offsets.emplace_back(precompute_circle(r));
    }

    SDL_Init(SDL_INIT_VIDEO);

    SDL_Delay(200);
    SDL_Window* window = SDL_CreateWindow("Water Particle Simulation", win_x, win_y, SDL_WINDOW_RESIZABLE);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, nullptr);
    SDL_Texture* particle_level = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);

    TTF_Init();
    TTF_Font* arial17 = TTF_OpenFont("arial.ttf", 17);
    TTF_Font* arial12 = TTF_OpenFont("arial.ttf", 12);

    SDL_Surface* text;

    std::vector<SDL_Texture*> var_display_names;

    std::vector<const char*> var_names = { 
        "Number of particles", 
        "Particle influence radius",
        "Gravity", "Target density", 
        "Pressure multiplier", 
        "Viscosity multiplier", 
        "Mouse influence radius", 
        "Mouse influence strength" 
    };

    int slider_w = 750;
    int slider_h = 45;
    SDL_Texture* slider = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, slider_w, slider_h);

    slider = create_slider(renderer, slider, slider_w, slider_h);

    slider_w *= 0.4f;
    slider_h *= 0.4f;

    slider = resize_texture(renderer, slider, slider_w, slider_h);

    std::vector<std::vector<float>> vals = {
        {num_particles, 500, 8000},
        {influence_radius, 10, 150},
        {gravity, 0.0f, 1.5f},
        {target_density, 0.0f, 12.0f},
        {pressure_multiplier, 0.01f, 5.0f},
        {viscosity_multiplier, 0.0f, 1.0f},
        {mouse_range, 20.0f, 500.0f},
        {mouse_strength, 0.01f, 3.0f}
    };

    int num_sliders = vals.size();

    std::vector<float*> traceback = { 
        &num_particles, 
        &influence_radius, 
        &gravity, 
        &target_density, 
        &pressure_multiplier, 
        &viscosity_multiplier, 
        &mouse_range, 
        &mouse_strength
    };

    std::vector<SDL_FRect> sliders;
    
    for (int i = 0; i < num_sliders; i++) {
        sliders.push_back(SDL_FRect{ 30, 35 + float(100*i), float(slider_w), float(slider_h) });
    }

    for (int i = 0; i < num_sliders; i++) {
        knobs.emplace_back(renderer, traceback[i], vals[i][0], sliders[i].y + sliders[i].h * 0.5f, sliders[i].x + sliders[i].h * 0.5f, sliders[i].x + sliders[i].w - sliders[i].h * 0.5f, vals[i][1], vals[i][2], arial12);
    }

    SDL_Texture* tex;
    SDL_Surface* surf;
    SDL_Color color = { 255,255,255,255 };
    
    for (int i = 0; i < num_sliders; i++) {
        surf = TTF_RenderText_Blended(arial17, var_names[i], SDL_strnlen(var_names[i],40), color);
        tex = SDL_CreateTextureFromSurface(renderer, surf);
        var_display_names.emplace_back(tex);
    }

    std::vector<SDL_FRect> var_rects;

    for (int i = 0; i < num_sliders; i++) {
        float w, h;

        SDL_GetTextureSize(var_display_names[i], &w, &h);

        var_rects.emplace_back(SDL_FRect{sliders[i].x + 12, sliders[i].y - 24, w, h});
    }

    SDL_Event event;

    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_ADD);

    for (int i = 0; i < num_particles; i++) {
        particles.emplace_back(i, random(gen) * win_x, random(gen) * win_y);
        new_particles.emplace_back(particles[i]);
        current_p.emplace_back(&particles[i]);
        new_p.emplace_back(&particles[i]);
    }

    for (int i = 0; i < num_particles; i++) {
        current_p[i] = &particles[i];
        new_p[i] = &new_particles[i];
    }

    float density;
    float dx, dy;
    float dist;
    float q, q2;
    float m;

    float x, y;
    float px, py;
    float vx, vy;
    float f, fx, fy;
    float nx, ny;

    float pressure_i;
    float pressure_j;

    float inv_d, inv_dnsty;

    std::vector<Particle*> neighbors;

    Uint64 frame_start;
    Uint64 frame_time;

    bool active = true;
    while (active) {
        frame_start = SDL_GetTicks();

        SDL_SetRenderTarget(renderer, nullptr);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderTarget(renderer, particle_level);
        SDL_RenderClear(renderer);

        grid.clear();
        for (auto& p : particles) {
            grid[{p.cx, p.cy}].push_back(&p);
        }

        for (auto& p : particles) {
            density = 0;

            for (auto& neighbor : get_neighbors(p)) {
                dx = neighbor->px - p.px;
                dy = neighbor->py - p.py;
                dist = dx * dx + dy * dy;

                if (dist < radius_sq) {
                    q = (influence_radius - std::sqrt(dist)) * inv_r;
                    density += q * q * q;
                }
            }

            p.density = std::max(density, 0.000001f);
        }

        for (int i = 0; i < num_particles; i++) {
            Particle* p = current_p[i];
            Particle* np = new_p[i];

            x = p->x;
            y = p->y;
            px = p->px;
            py = p->py;
            vx = p->vx;
            vy = p->vy;

            fx = 0.0f;
            fy = 0.0f;

            pressure_i = (p->density - target_density) * pressure_multiplier;

            for (auto* neighbor : get_neighbors(*p)) {
                if (neighbor == p) { continue; }

                dx = neighbor->px - px;
                dy = neighbor->py - py;
                dist = dx * dx + dy * dy;

                if (dist == 0) {
                    x += 0.1;
                }
                if (dist < radius_sq) {
                    dist = std::sqrt(dist);

                    inv_d = 1.0f / dist;

                    nx = dx * inv_d;
                    ny = dy * inv_d;

                    pressure_j = (neighbor->density - target_density) * pressure_multiplier;

                    q = (influence_radius - dist) * inv_r;
                    q2 = q * q;

                    f = (pressure_i + pressure_j) * 0.5f * q2;

                    fx -= f * nx;
                    fy -= f * ny;

                    inv_dnsty = 1.0f / neighbor->density;

                    q = inv_dnsty * q2 * viscosity_multiplier;

                    fx += (neighbor->vx - vx) * q;
                    fy += (neighbor->vy - vy) * q;
                }
            }

            np->vx = vx + fx;
            np->vy = vy + fy + gravity;

            m = std::sqrt(np->vx * np->vx + np->vy * np->vy);
            
            if (render_colors) {
                float m2 = m * m;
                float m3 = m2 * m;
                    
                np->r = std::max(std::min(-0.05749f * m3 + 5.0862f * m2 - 11.6955f * m - 74.6891f, 255.0f), 0.0f);
                np->g = std::max(std::min(-4.3622f * m2 + 73.8972f * m + 15.2779f, 255.0f), 0.0f);
                np->b = std::max(std::min(0.132f * m3 - 2.1667f * m2 - 16.4031f * m + 240.3318f, 255.0f), 0.0f);
            }

            if (m > 35.0f) {
                m = 1.0f / m;
                np->vx *= m;
                np->vy *= m;
            }

            np->x = x + np->vx;
            np->y = y + np->vy;

            if (np->x < 0) {
                np->x = 0.0f;
                np->vx *= -0.5f;
            }
            else if (np->x > win_x) {
                if (np->x > win_x * 1.1f) {
                    np->x = random(gen) * win_x;
                }
                else {
                    np->x = win_x;
                    np->vx *= -0.5f;
                }
            }
            if (np->y < 0) {
                np->y = 0.0f;
                np->vy *= -0.5f;
            }
            else if (np->y > win_y) {
                if (np->y > win_y * 1.1f) {
                    np->y = random(gen) * win_y;
                }
                else {
                    np->y = win_y;
                    np->vy *= -0.5f;
                }
            }

            np->px = np->x + np->vx;
            np->py = np->y + np->vy;

            np->cx = std::floor(np->x * inv_cs);
            np->cy = std::floor(np->y * inv_cs);

            if (!show_ui) {
                dx = mouse_x - np->x;
                dy = mouse_y - np->y;
                dist = dx * dx + dy * dy;

                if (dist < mouse_range_sq && dist != 0) {
                    dist = mouse_strength / std::sqrt(dist);
                    if (l_button) {
                        np->vx -= dx * dist;
                        np->vy -= dy * dist;
                    }
                    if (r_button) {
                        np->vx += dx * dist;
                        np->vy += dy * dist;
                    }
                }
            }
        }

        particles.swap(new_particles);

        for (int i = 0; i < num_particles; i++) {
            current_p[i] = &particles[i];
            new_p[i] = &new_particles[i];
        }

        if (render_colors) {
            for (auto& p : particles) {
                SDL_SetRenderDrawColor(renderer, p.r, p.g, p.b, 156);
                render(renderer, 0, p.x, p.y);
            }
        }
        else {
            SDL_SetRenderDrawColor(renderer, 0, 40, 240, 156);

            for (auto& p : particles) {
                render(renderer, 0, p.x, p.y);
            }
        }

        SDL_SetRenderTarget(renderer, nullptr);
        SDL_RenderTexture(renderer, particle_level, nullptr, nullptr);

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

        if (show_ui) {
            for (auto& s : sliders) {
                SDL_RenderTexture(renderer, slider, nullptr, &s);
            }

            for (auto& k : knobs) {
                if ((mouse_x > k.x - 12.0f && mouse_x < k.x + 12.0f && mouse_y > k.y - 12.0f && mouse_y < k.y + 12.0f) || k.move) {
                    dx = mouse_x - k.x;
                    dy = mouse_y - k.y;

                    if (dx * dx + dy * dy <= 144 && l_button) {
                        k.move = true;
                    }
                    if (k.move && l_button) {
                        k.x = std::max(std::min(mouse_x, k.max_x), k.min_x);

                        k.update_variable();
                        k.update_val_label(renderer, arial12);
                    }
                    else {
                        k.move = false;
                    }
                }
                render(renderer, 1, k.x, k.y);
            }

            for (int i = 0; i < num_sliders; i++) {
                SDL_RenderTexture(renderer, var_display_names[i], nullptr, &var_rects[i]);
                SDL_RenderTexture(renderer, knobs[i].display_val, nullptr, &knobs[i].display_val_position);
            }
        }

        SDL_RenderPresent(renderer);

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_EVENT_QUIT) {
                active = false;
            }
            else {
                switch (event.type) {
                case SDL_EVENT_MOUSE_MOTION:
                    mouse_x = event.motion.x;
                    mouse_y = event.motion.y;
                    break;

                case SDL_EVENT_MOUSE_BUTTON_DOWN:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        l_button = true;
                    }
                    else if (event.button.button == SDL_BUTTON_RIGHT) {
                        r_button = true;
                    }
                    break;

                case SDL_EVENT_MOUSE_BUTTON_UP:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        l_button = false;
                    }
                    else if (event.button.button == SDL_BUTTON_RIGHT) {
                        r_button = false;
                    }
                    break;

                case SDL_EVENT_WINDOW_RESIZED:
                    win_x = event.window.data1;

                    if (event.window.data2 < win_y) {
                        win_y = event.window.data2;

                        for (int i = 0; i < num_sliders; i++) {
                            if (knobs[i].y > win_y - 35) {
                                if (sliders[i].x == 450) {
                                    break;
                                }
                                int new_column_start = i;
                                float range;
                                SliderKnob* knob;
                                SDL_FRect* s;

                                for (i; i < num_sliders; i++) {
                                    knob = &knobs[i];
                                    s = &sliders[i];

                                    s->x = 450;
                                    s->y = 35 + 100 * (i - new_column_start);

                                    knob->y = s->y + s->h * 0.5f;

                                    range = knob->max_x - knob->min_x;
                                    knob->min_x = s->x + s->h * 0.5f;
                                    knob->max_x = knob->min_x + range;
                                    knob->x = knob->min_x + (*knob->val - knob->min_val) / (knob->max_val - knob->min_val) * (knob->max_x - knob->min_x);

                                    var_rects[i] = SDL_FRect{ sliders[i].x + 12, sliders[i].y - 24, var_rects[i].w, var_rects[i].h };
                                    knob->update_val_label(renderer, arial12);
                                }

                                break;
                            }
                        }
                    }
                    else {
                        win_y = event.window.data2;

                        for (int i = 0; i < num_sliders; i++) {
                            if (sliders[i].x == 450) {
                                float range;
                                SliderKnob* knob;
                                SDL_FRect* s;

                                for (int j = 0; j+i < num_sliders; j++) {
                                    if ((i+j) * 100 > win_y - 70) {
                                        for (i; i+j < num_sliders; i++) {
                                            sliders[i+j].y -= 100 * j;
                                            knobs[i+j].y -= 100 * j;

                                            var_rects[i+j] = SDL_FRect{ sliders[i+j].x + 12, sliders[i+j].y - 24, var_rects[i+j].w, var_rects[i+j].h };
                                            knobs[i+j].update_val_label(renderer, arial12);
                                        }
                                        
                                        break;
                                    }

                                    knob = &knobs[i+j];
                                    s = &sliders[i+j];

                                    s->x = 30;
                                    s->y = 35 + 100 * (i+j);

                                    knob->y = s->y + s->h * 0.5f;
                                    range = knob->max_x - knob->min_x;
                                    knob->min_x = s->x + s->h * 0.5f;
                                    knob->max_x = knob->min_x + range;
                                    knob->x = knob->min_x + (*knob->val - knob->min_val) / (knob->max_val - knob->min_val) * (knob->max_x - knob->min_x);

                                    var_rects[i + j] = SDL_FRect{ s->x + 12, s->y - 24, var_rects[i+j].w, var_rects[i+j].h };
                                    knob->update_val_label(renderer, arial12);
                                }

                                break;
                            }
                        }
                    }

                    SDL_DestroyTexture(particle_level);

                    particle_level = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y); SDL_SetRenderTarget(renderer, particle_level);

                    break;

                case SDL_EVENT_KEY_DOWN:
                    if (event.key.key == SDLK_C) {
                        render_colors = !render_colors;
                    }
                    else if (event.key.key == SDLK_LALT or event.key.key == SDLK_RALT) {
                        show_ui = !show_ui;
                    }
                    break;

                }
            }
        }

        frame_time = SDL_GetTicks() - frame_start;

        if (frame_time < delay) {
            SDL_Delay(delay - frame_time);
        }
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    TTF_Quit();
    return 0;
}
