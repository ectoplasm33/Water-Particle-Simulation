Run the executeable file to run the water simulation.

Controls:
left mouse button: repel
right mouse button: attract
c key: show/hide velocity colors 
alt key: edit variables
    ranges and identification:
    1. number of particles (500-10000)
    2. influence radius (10-150)
    3. gravity (0-1.5)
    4. target density (0-12)
    5. pressure multiplier (0.01-5)
    6. viscosity multiplier (0-1)
    7. mouse influence radius (20-500)
    8. mouse influence strength (0.01-3)

Increased efficiency slightly to run faster. 