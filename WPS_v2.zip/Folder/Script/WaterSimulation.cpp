// WaterSimulation.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <SDL3/SDL.h>
#include <iostream>
#include <cmath>
#include <vector>
#include <random>
#include <unordered_map>

std::random_device rd;
std::mt19937 gen(rd());

std::uniform_real_distribution<float> random(0.0f, 1.0f);

int win_x = 1500; int win_y = std::floor(win_x * 9.0f / 16.0f);

const int circle_radius = 3;

const int num_particles = 4000;
const int influence_radius = 48;
const float target_density = 4.3f;
const float pressure_multiplier = 0.3f;
const float viscosity_multiplier = 0.13f;

const float gravity = 0.3f;

const int radius_sq = influence_radius * influence_radius;
const float inv_r = 1.0f / influence_radius;
const int cell_size = influence_radius;
const float inv_cs = 1.0f / cell_size;

const int target_fps = 200;
const float delay = 1000 / target_fps;

const int mouse_range = 250;
const int mouse_range_sq = mouse_range * mouse_range;

bool l_button = false;
bool r_button = false;

float mouse_x;
float mouse_y;

bool render_colors = false;

static std::vector<std::pair<std::pair<float, float>, std::pair<float, float>>> precomputeCircle(float r) {
    std::vector<std::pair<std::pair<float, float>, std::pair<float, float>>> offsets;

    float r2 = r * r;
    float dy;

    for (float dx = -r; dx <= r; dx++) {
        dy = std::floor(std::sqrt(r2 - dx * dx));

         offsets.emplace_back(std::make_pair(dx, dy), std::make_pair(dx, -dy));
    }
    
    return offsets;
}

std::vector<std::pair<std::pair<float, float>, std::pair<float, float>>> circle_offsets = precomputeCircle(circle_radius);

struct hash_key {
    std::size_t operator()(const std::pair<int, int>& p) const noexcept {
        return ((std::size_t)p.first << 32) ^ (std::size_t)p.second;
    }
};

class Particle {
public:
    float x, y, vx, vy, px, py, density;
    int cx, cy, idx;
    Uint8 r, g, b, a;
    Particle(int i, float initial_x, float initital_y) {
        x = initial_x;
        y = initital_y;
        vx = 0;
        vy = 0;
        px = x;
        py = y;
        cx = std::floor(x * inv_cs);
        cy = std::floor(y * inv_cs);

        r = 30;
        g = 50;
        b = 255;
        a = 156;

        idx = i;
    }
};

inline void render(SDL_Renderer* renderer, float x, float y) {
    for (auto& seg : circle_offsets) {
        SDL_RenderLine(renderer, x + seg.first.first, y + seg.first.second, x + seg.second.first, y + seg.second.second);
    }
}

std::vector<Particle> particles;
std::vector<Particle> new_particles;

std::vector<Particle*> current_p;
std::vector<Particle*> new_p;

std::unordered_map<std::pair<int, int>, std::vector<Particle*>, hash_key> grid;

inline std::vector<Particle*> get_neighbors(Particle& p) {
    int cx = p.cx;
    int cy = p.cy;

    std::vector<Particle*> neighbors;

    for (int i = -1; i < 2; i++) {
        for (int j = -1; j < 2; j++) {
            auto cell = grid.find({ cx + i, cy + j });

            if (cell != grid.end()) {
                neighbors.insert(neighbors.end(), cell->second.begin(), cell->second.end());
            }
        }
    }

    return neighbors;
}

int main() {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Delay(200);
    SDL_Window* window = SDL_CreateWindow("Water Particle Simulation", win_x, win_y, SDL_WINDOW_RESIZABLE);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, nullptr);
    SDL_Texture* particle_level = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y);SDL_SetRenderTarget(renderer, particle_level);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_ADD);

    SDL_Event event;

    for (int i = 0; i < num_particles; i++) {
        particles.emplace_back(i, random(gen) * win_x, random(gen) * win_y);
        new_particles.emplace_back(particles[i]);
        current_p.emplace_back(&particles[i]);
        new_p.emplace_back(&particles[i]);
    }

    for (int i = 0; i < num_particles; i++) {
        current_p[i] = &particles[i];
        new_p[i] = &new_particles[i];
    }

    float density;
    float dx, dy;
    float dist;
    float q, q2;
    float m;

    float x, y;
    float px, py;
    float vx, vy;
    float f, fx, fy;
    float nx, ny;

    float pressure_i;
    float pressure_j;

    float inv_d, inv_dnsty;

    std::vector<Particle*> neighbors;

    Uint64 frame_start;
    Uint64 frame_time;

    bool active = true;
    while (active) {
        frame_start = SDL_GetTicks();

        SDL_SetRenderTarget(renderer, nullptr);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderTarget(renderer, particle_level);
        SDL_RenderClear(renderer);

        grid.clear();
        for (auto& p : particles) {
            grid[{p.cx, p.cy}].push_back(&p);
        }

        for (auto& p : particles) {
            density = 0;

            for (auto& neighbor : get_neighbors(p)) {
                dx = neighbor->px - p.px;
                dy = neighbor->py - p.py;
                dist = dx * dx + dy * dy;

                if (dist < radius_sq) {
                    q = (influence_radius - std::sqrt(dist)) * inv_r;
                    density += q * q * q;
                }
            }

            p.density = std::max(density, 0.000001f);
        }

        for (int i = 0; i < num_particles; i++) {
            Particle* p = current_p[i];
            Particle* np = new_p[i];

            x = p->x;
            y = p->y;
            px = p->px;
            py = p->py;
            vx = p->vx;
            vy = p->vy;

            fx = 0.0f;
            fy = 0.0f;

            pressure_i = (p->density - target_density) * pressure_multiplier;

            for (auto* neighbor : get_neighbors(*p)) {
                if (neighbor == p) { continue; }

                dx = neighbor->px - px;
                dy = neighbor->py - py;
                dist = dx * dx + dy * dy;

                if (dist == 0) {
                    x += 0.1;
                }
                if (dist < radius_sq) {
                    dist = std::sqrt(dist);

                    inv_d = 1.0f / dist;

                    nx = dx * inv_d;
                    ny = dy * inv_d;

                    pressure_j = (neighbor->density - target_density) * pressure_multiplier;

                    q = (influence_radius - dist) * inv_r;
                    q2 = q * q;

                    f = (pressure_i + pressure_j) * 0.5f * q2;

                    fx -= f * nx;
                    fy -= f * ny;

                    inv_dnsty = 1.0f / neighbor->density;

                    q = inv_dnsty * q2 * viscosity_multiplier;

                    fx += (neighbor->vx - vx) * q;
                    fy += (neighbor->vy - vy) * q;
                }
            }

            np->vx = vx + fx;
            np->vy = vy + fy + gravity;

            m = std::sqrt(np->vx * np->vx + np->vy * np->vy);
            
            if (render_colors) {
                float m2 = m * m;
                float m3 = m2 * m;
                    
                np->r = std::max(std::min(-0.05749f * m3 + 5.0862f * m2 - 11.6955f * m - 74.6891f, 255.0f), 0.0f);
                np->g = std::max(std::min(-4.3622f * m2 + 73.8972f * m + 15.2779f, 255.0f), 0.0f);
                np->b = std::max(std::min(0.132f * m3 - 2.1667f * m2 - 16.4031f * m + 240.3318f, 255.0f), 0.0f);
            }

            if (m > 35.0f) {
                m = 1.0f / m;
                np->vx *= m;
                np->vy *= m;
            }



            np->x = x + np->vx;
            np->y = y + np->vy;

            if (np->x < 0) {
                np->x = 0.0f;
                np->vx *= -0.5f;
            }
            else if (np->x > win_x) {
                if (np->x > win_x * 1.1f) {
                    np->x = random(gen) * win_x;
                }
                else {
                    np->x = win_x;
                    np->vx *= -0.5f;
                }
            }
            if (np->y < 0) {
                np->y = 0.0f;
                np->vy *= -0.5f;
            }
            else if (np->y > win_y) {
                if (np->y > win_y * 1.1f) {
                    np->y = random(gen) * win_y;
                }
                else {
                    np->y = win_y;
                    np->vy *= -0.5f;
                }
            }

            np->px = np->x + np->vx;
            np->py = np->y + np->vy;

            np->cx = std::floor(np->x * inv_cs);
            np->cy = std::floor(np->y * inv_cs);

            dx = mouse_x - np->x;
            dy = mouse_y - np->y;
            dist = dx * dx + dy * dy;

            if (dist < mouse_range_sq && dist != 0) {
                dist = 1.0f / std::sqrt(dist);
                if (l_button) {
                    np->vx -= dx * dist * 0.4f;
                    np->vy -= dy * dist * 0.4f;
                }
                if (r_button) {
                    np->vx += dx * dist * 0.7f;
                    np->vy += dy * dist * 0.7f;
                }
            }
        }

        particles.swap(new_particles);

        for (int i = 0; i < num_particles; i++) {
            current_p[i] = &particles[i];
            new_p[i] = &new_particles[i];
        }

        if (render_colors) {
            for (auto& p : particles) {
                SDL_SetRenderDrawColor(renderer, p.r, p.g, p.b, 156);
                render(renderer, p.x, p.y);
            }
        }
        else {
            SDL_SetRenderDrawColor(renderer, 0, 40, 240, 156);

            for (auto& p : particles) {
                render(renderer, p.x, p.y);
            }
        }

        SDL_SetRenderTarget(renderer, nullptr);
        SDL_RenderTexture(renderer, particle_level, nullptr, nullptr);
        SDL_RenderPresent(renderer);

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_EVENT_QUIT) {
                active = false;
            }
            else {
                switch (event.type) {
                case SDL_EVENT_MOUSE_MOTION:
                    mouse_x = event.motion.x;
                    mouse_y = event.motion.y;
                    break;

                case SDL_EVENT_MOUSE_BUTTON_DOWN:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        l_button = true;
                    }
                    else if (event.button.button == SDL_BUTTON_RIGHT) {
                        r_button = true;
                    }
                    break;

                case SDL_EVENT_MOUSE_BUTTON_UP:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        l_button = false;
                    }
                    else if (event.button.button == SDL_BUTTON_RIGHT) {
                        r_button = false;
                    }
                    break;

                case SDL_EVENT_WINDOW_RESIZED:
                    win_x = event.window.data1;
                    win_y = event.window.data2;

                    SDL_DestroyTexture(particle_level);

                    particle_level = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, win_x, win_y); SDL_SetRenderTarget(renderer, particle_level);

                    break;

                case SDL_EVENT_KEY_DOWN:
                    if (event.key.key == SDLK_C) {
                        render_colors = !render_colors;
                    }
                    break;
                }
            }
        }

        frame_time = SDL_GetTicks() - frame_start;

        if (frame_time < delay) {
            SDL_Delay(delay - frame_time);
        }
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
