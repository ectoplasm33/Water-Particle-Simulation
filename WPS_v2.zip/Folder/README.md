Run the executeable file to run the water simulation.

Controls:
left mouse button: repel
right mouse button: attract
c key: show/hide velocity colors 

Bug fixes:
particles now smoothly transition when shrinking the window size. 
fixed the issue of particles collapsing on one another. 